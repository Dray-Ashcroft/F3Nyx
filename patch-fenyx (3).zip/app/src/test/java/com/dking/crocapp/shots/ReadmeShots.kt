package com.dking.crocapp.shots

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performTouchInput
import androidx.compose.ui.test.swipeUp
import androidx.compose.ui.test.captureToImage
import androidx.lifecycle.ViewModelProvider
import com.dking.crocapp.MainActivity
import com.dking.crocapp.croc.BinarySetupPhase
import com.dking.crocapp.croc.BinarySetupState
import com.dking.crocapp.croc.CrocTransferState
import com.dking.crocapp.data.preferences.UserPreferencesRepository
import com.dking.crocapp.ui.receive.ReceiveViewModel
import com.dking.crocapp.ui.receive.ReceivedFile
import com.dking.crocapp.ui.send.SelectedFile
import com.dking.crocapp.ui.send.SendViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.runBlocking
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/** Renders the README screenshots. Run: gradle testStandardDebugUnitTest --tests '*ReadmeShots*' -Pshots */
@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(sdk = [34])
class ReadmeShots {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    private val out = File(System.getProperty("shots.dir") ?: "build/shots").apply { mkdirs() }

    private fun field(o: Any, name: String): Any? {
        var c: Class<*>? = o.javaClass
        while (c != null) {
            try { return c.getDeclaredField(name).apply { isAccessible = true }.get(o) } catch (_: NoSuchFieldException) {}
            c = c.superclass
        }
        error("no field $name")
    }
    @Suppress("UNCHECKED_CAST")
    private fun <T> flow(o: Any, name: String) = field(o, name) as MutableStateFlow<T>

    private fun panelMode(on: Boolean) = runBlocking {
        UserPreferencesRepository(androidx.test.core.app.ApplicationProvider.getApplicationContext()).updatePanelMode(on)
    }

    private fun ready() {
        com.dking.crocapp.ui.components.SuitCue.done()
        val app = rule.activity.application as com.dking.crocapp.CrocApp
        flow<BinarySetupState>(app.binaryManager, "_setupState").value = BinarySetupState(phase = BinarySetupPhase.Ready)
    }
    private fun send() = ViewModelProvider(rule.activity)[SendViewModel::class.java]
    private fun recv() = ViewModelProvider(rule.activity)[ReceiveViewModel::class.java]

    private fun settle(ms: Long = 1500) {
        rule.mainClock.autoAdvance = false
        repeat((ms / 50).toInt()) {
            rule.mainClock.advanceTimeBy(50)
            org.robolectric.shadows.ShadowLooper.idleMainLooper(50, java.util.concurrent.TimeUnit.MILLISECONDS)
        }
    }
    private fun shot(name: String) {
        rule.waitForIdle()
        val v = rule.activity.window.decorView
        val bmp = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        rule.runOnUiThread { v.draw(android.graphics.Canvas(bmp)) }
        File(out, "$name.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    private val files = listOf(
        SelectedFile(Uri.parse("content://x/1"), "Photosynthesis_notes.pdf", 4_812_000),
        SelectedFile(Uri.parse("content://x/2"), "Cell_division.mp4", 18_400_000),
        SelectedFile(Uri.parse("content://x/3"), "Lab_report.docx", 1_380_000)
    )

    @Test @Config(qualifiers = "w411dp-h891dp-night-xxhdpi")
    fun phone() {
        panelMode(false)
        ready()
        settle(300)
        val s = send()
        flow<com.dking.crocapp.ui.send.SendUiState>(s, "_uiState").value =
            flow<com.dking.crocapp.ui.send.SendUiState>(s, "_uiState").value.copy(
                selectedFiles = files, selectedBytes = files.sumOf { it.size }, codePhrase = "4821-amber-falcon-river"
            )
        settle(); shot("Phone")
    }

    @Test @Config(qualifiers = "w411dp-h891dp-night-xxhdpi")
    fun transmit() {
        panelMode(false)
        ready()
        settle(300)
        val s = send()
        val st = flow<com.dking.crocapp.ui.send.SendUiState>(s, "_uiState")
        st.value = st.value.copy(selectedFiles = files, selectedBytes = files.sumOf { it.size }, codePhrase = "4821-amber-falcon-river")
        flow<CrocTransferState>(field(s, "crocProcess")!!, "_state").value = CrocTransferState.Transferring(
            fileName = "Cell_division.mp4", currentFile = 2, totalFiles = 3, currentFilePercent = 62,
            bytesTransferred = 16_200_000, totalBytes = 24_592_000, speedBytesPerSec = 3_400_000, etaSeconds = 3
        )
        settle(600)
        // Scroll the page down so the progress ring is in view.
        rule.onAllNodes(androidx.compose.ui.test.hasScrollAction())[0]
            .performTouchInput { swipeUp(startY = bottom - 10f, endY = top + 10f, durationMillis = 400) }
        settle(2000); shot("Transmit")
    }

    @Test @Config(qualifiers = "w411dp-h891dp-night-xxhdpi")
    fun retrieve() {
        panelMode(false)
        ready()
        settle(300)
        rule.runOnUiThread { }
        // Go to the Retrieve tab via the dock.
        rule.onNode(androidx.compose.ui.test.hasContentDescription(rule.activity.getString(com.dking.crocapp.R.string.nav_receive))).performClickSafe()
        val r = recv()
        val st = flow<com.dking.crocapp.ui.receive.ReceiveUiState>(r, "_uiState")
        val got = listOf(
            ReceivedFile("Photosynthesis_notes.pdf", "Downloads/F3Nyx", Uri.parse("content://y/1"), "application/pdf"),
            ReceivedFile("Cell_division.mp4", "Downloads/F3Nyx", Uri.parse("content://y/2"), "video/mp4"),
            ReceivedFile("Lab_report.docx", "Downloads/F3Nyx", Uri.parse("content://y/3"), "application/msword")
        )
        st.value = st.value.copy(
            codePhrase = "4821-amber-falcon-river",
            transferState = CrocTransferState.Completed(got.map { it.name }, 24_592_000, totalFileCount = 3),
            receivedFiles = got
        )
        settle((System.getProperty("shots.landMs") ?: "3200").toLong()); shot("Retrieve")
    }

    @Test @Config(qualifiers = "w1280dp-h720dp-land-night-hdpi")
    fun panel() {
        panelMode(true)
        ready()
        settle(800)
        val r = recv()
        (field(r, "panelWatcher") as Job?)?.cancel()
        (field(r, "receiveJob") as Job?)?.cancel()
        flow<CrocTransferState>(field(r, "crocProcess")!!, "_state").value = CrocTransferState.WaitingForPeer("4821-amber-falcon-river")
        val st = flow<com.dking.crocapp.ui.receive.ReceiveUiState>(r, "_uiState")
        st.value = st.value.copy(
            codePhrase = "4821-amber-falcon-river",
            transferState = CrocTransferState.WaitingForPeer("4821-amber-falcon-river"),
            panelCodeIssuedAt = System.currentTimeMillis(),
            sessionFiles = listOf(
                ReceivedFile("Photosynthesis_notes.pdf", "Downloads/F3Nyx", Uri.parse("content://y/1"), "application/pdf"),
                ReceivedFile("Lab_report.docx", "Downloads/F3Nyx", Uri.parse("content://y/3"), "application/msword")
            )
        )
        settle(1500); shot("Panel")
    }


    private fun androidx.compose.ui.test.SemanticsNodeInteraction.performClickSafe() {
        try { performClick() } catch (e: Throwable) { println("click failed: $e") }
    }
}
