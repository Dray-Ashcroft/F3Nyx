package com.dking.crocapp.ui.receive

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.InsertDriveFile
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.dking.crocapp.ui.components.GlassCard
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.foundation.border
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import com.dking.crocapp.R
import com.dking.crocapp.croc.CrocTransferState
import com.dking.crocapp.ui.components.EngineBadge
import com.dking.crocapp.ui.components.TransferProgressCard
import com.dking.crocapp.ui.components.formatBytes
import com.dking.crocapp.ui.components.progressBorder

private const val MAX_VISIBLE_FILES = 6

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ReceiveScreen(
    viewModel: ReceiveViewModel = viewModel(),
    onOpenScanner: () -> Unit = {},
    onNavigateToHistory: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {}
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    // Smart-panel mode: a big self-refreshing QR instead of the code form.
    if (uiState.panelMode) {
        PanelReceiveScreen(
            viewModel = viewModel,
            onNavigateToHistory = onNavigateToHistory,
            onNavigateToSettings = onNavigateToSettings
        )
        return
    }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var hideCodePhrase by remember { mutableStateOf(false) }
    var showCodeMenu by remember { mutableStateOf(false) }
    var showAllFiles by remember { mutableStateOf(false) }
    val codeFocusRequester = remember { FocusRequester() }
    var highlightCodeInput by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.codePhrase) {
        if (uiState.codePhrase.isNotBlank()) {
            highlightCodeInput = false
        }
    }

    // SAF folder picker for session-level location override
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            // Take persistent read/write permission
            val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
            viewModel.setSessionOverrideLocation(uri)
        }
    }

    val isTransferActive = uiState.transferState is CrocTransferState.Preparing ||
            uiState.transferState is CrocTransferState.WaitingForPeer ||
            uiState.transferState is CrocTransferState.Transferring
    val isTransferFinished = uiState.transferState is CrocTransferState.Completed ||
            uiState.transferState is CrocTransferState.Error ||
            uiState.transferState is CrocTransferState.Cancelled
    val isLegacyFallback = uiState.transferState is CrocTransferState.LegacyFallbackAvailable
    val showTransferSection = isTransferActive || isTransferFinished || isLegacyFallback
    val canReceive = uiState.codePhrase.isNotBlank()
    val fabLabel = when (uiState.transferState) {
        is CrocTransferState.Completed -> stringResource(R.string.receive_again)
        is CrocTransferState.LegacyFallbackAvailable -> stringResource(R.string.action_retry_legacy)
        is CrocTransferState.Error, CrocTransferState.Cancelled -> stringResource(R.string.action_retry)
        else -> stringResource(R.string.nav_receive)
    }

    // Animated progress for the code card border
    val transferProgress = when (val state = uiState.transferState) {
        is CrocTransferState.Transferring -> state.fileCountProgress
        is CrocTransferState.Completed -> 1f
        else -> 0f
    }
    val animatedBorderProgress by animateFloatAsState(
        targetValue = transferProgress,
        animationSpec = tween(400),
        label = "codeBorderProgress"
    )
    val showCodeBorder = isTransferActive || uiState.transferState is CrocTransferState.Completed
    val borderColor = MaterialTheme.colorScheme.tertiary

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        com.dking.crocapp.ui.components.LogoMark(modifier = Modifier.padding(end = 10.dp).size(28.dp))
                        Text(
                            stringResource(R.string.nav_receive),
                            fontWeight = FontWeight.Bold
                        )
                        com.dking.crocapp.ui.components.ModeDot(modifier = Modifier.padding(start = 4.dp))
                    }
                },
                actions = {
                    IconButton(onClick = onNavigateToHistory) {
                        Icon(Icons.Outlined.History, contentDescription = stringResource(R.string.nav_history))
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = stringResource(R.string.nav_settings))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent,
                    scrolledContainerColor = Color.Transparent
                ),
                // The app's outer Scaffold already pads for the status bar.
                windowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0)
            )
        },
        bottomBar = {
            // ③ Full-width main action (same behaviour as the old floating button:
            // with no code yet it points you to the code field).
            if (!isTransferActive) {
                com.dking.crocapp.ui.components.RegisterDockAction(
                    key = "receive",
                    text = fabLabel,
                    icon = if (isLegacyFallback) Icons.Rounded.History else Icons.Rounded.Download,
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                    onClick = {
                        if (isLegacyFallback) {
                            viewModel.retryWithLegacy()
                        } else {
                            if (uiState.codePhrase.isBlank()) {
                                highlightCodeInput = true
                                codeFocusRequester.requestFocus()
                            } else {
                                if (isTransferFinished) {
                                    viewModel.dismissTransferResult()
                                }
                                viewModel.startReceive()
                            }
                        }
                    }
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(2.dp))

            // ──── Code Entry Card — with animated progress border ────
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .then(
                        if (showCodeBorder) {
                            Modifier.progressBorder(
                                progress = animatedBorderProgress,
                                color = borderColor,
                                cornerRadius = 28.dp
                            )
                        } else if (highlightCodeInput && uiState.codePhrase.isBlank()) {
                            Modifier.border(
                                width = 2.dp,
                                color = MaterialTheme.colorScheme.error,
                                shape = MaterialTheme.shapes.extraLarge
                            )
                        } else Modifier
                    ),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                ),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    com.dking.crocapp.ui.components.StepTitle(
                        number = 1,
                        title = stringResource(R.string.send_secret_code)
                    ) {
                        if (uiState.defaultCodePhrase.isNotBlank() && uiState.defaultCodePhrase == uiState.codePhrase) {
                            Text(
                                text = stringResource(R.string.label_default),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.tertiary
                            )
                        }
                        EngineBadge(engine = uiState.activeEngine)
                        Box {
                            IconButton(onClick = { showCodeMenu = true }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Rounded.MoreVert, contentDescription = stringResource(R.string.action_more_options))
                            }
                            androidx.compose.material3.DropdownMenu(
                                expanded = showCodeMenu,
                                onDismissRequest = { showCodeMenu = false }
                            ) {
                                if (com.dking.crocapp.BuildConfig.BUNDLES_LEGACY_ENGINE) androidx.compose.material3.DropdownMenuItem(
                                    text = {
                                        Text(
                                            if (uiState.activeEngine == com.dking.crocapp.croc.CrocEngine.LEGACY) stringResource(R.string.menu_use_latest_engine)
                                            else stringResource(R.string.menu_use_legacy_engine)
                                        )
                                    },
                                    enabled = !isTransferActive,
                                    onClick = { showCodeMenu = false; viewModel.toggleEngine() },
                                    leadingIcon = { Icon(Icons.Rounded.History, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                )
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { Text(stringResource(R.string.action_save)) },
                                    enabled = !isTransferActive && uiState.codePhrase.isNotBlank(),
                                    onClick = { showCodeMenu = false; viewModel.saveCurrentCode() },
                                    leadingIcon = { Icon(Icons.Rounded.Save, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                )
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { Text(stringResource(R.string.receive_clear_all)) },
                                    enabled = !isTransferActive && (uiState.codePhrase.isNotBlank() || uiState.receivedFiles.isNotEmpty()),
                                    onClick = { showCodeMenu = false; viewModel.resetTransfer() },
                                    leadingIcon = { Icon(Icons.Rounded.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp)) }
                                )
                                androidx.compose.material3.DropdownMenuItem(
                                    text = { Text(if (hideCodePhrase) stringResource(R.string.receive_show_code) else stringResource(R.string.receive_hide_code)) },
                                    onClick = { showCodeMenu = false; hideCodePhrase = !hideCodePhrase },
                                    leadingIcon = {
                                        Icon(
                                            if (hideCodePhrase) Icons.Rounded.Visibility else Icons.Rounded.VisibilityOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                )
                            }
                        }
                    }

                    // The easy way first: scan the sender's QR.
                    FilledTonalButton(
                        onClick = onOpenScanner,
                        enabled = !isTransferActive,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp),
                        shape = MaterialTheme.shapes.large,
                        colors = androidx.compose.material3.ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.10f),
                            contentColor = MaterialTheme.colorScheme.secondary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.35f))
                    ) {
                        Icon(Icons.Rounded.QrCodeScanner, contentDescription = null, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.receive_scan_sender_qr), fontWeight = FontWeight.SemiBold)
                    }
                    Text(
                        text = stringResource(R.string.receive_or_type),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = uiState.codePhrase,
                        onValueChange = {
                            highlightCodeInput = false
                            viewModel.updateCodePhrase(it)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(codeFocusRequester),
                        isError = highlightCodeInput && uiState.codePhrase.isBlank(),
                        enabled = !isTransferActive,
                        singleLine = true,
                        placeholder = { Text(stringResource(R.string.receive_code_placeholder)) },
                        shape = MaterialTheme.shapes.large,
                        textStyle = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = com.dking.crocapp.ui.theme.MonoFamily,
                            fontWeight = FontWeight.Medium
                        ),
                        visualTransformation = if (hideCodePhrase) PasswordVisualTransformation() else VisualTransformation.None,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val clip = clipboardManager.getText()?.text ?: ""
                                    viewModel.updateCodePhrase(clip)
                                }) {
                                    Icon(Icons.Rounded.ContentPaste, contentDescription = stringResource(R.string.receive_paste))
                                }
                                if (uiState.codePhrase.isNotBlank() && !isTransferActive) {
                                    IconButton(onClick = { viewModel.updateCodePhrase("") }) {
                                        Icon(Icons.Rounded.Close, contentDescription = stringResource(R.string.action_clear))
                                    }
                                }
                            }
                        }
                    )

                    // Saved codes — scrollable 2-row horizontal grid
                    if (uiState.savedCodePhrases.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            uiState.savedCodePhrases.chunked(2).forEach { column ->
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    column.forEach { savedCode ->
                                        SavedCodeChipWithActions(
                                            code = savedCode,
                                            enabled = !isTransferActive,
                                            onUse = { viewModel.startReceiveWithCode(savedCode) },
                                            onCopy = {
                                                clipboardManager.setText(
                                                    androidx.compose.ui.text.AnnotatedString(savedCode)
                                                )
                                            },
                                            onShare = {
                                                val shareIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                                    type = "text/plain"
                                                    putExtra(android.content.Intent.EXTRA_TEXT, savedCode)
                                                    putExtra(android.content.Intent.EXTRA_SUBJECT, "croc code")
                                                }
                                                context.startActivity(android.content.Intent.createChooser(shareIntent, "Share code"))
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ──── ② Where files are saved ────
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                ),
                shape = MaterialTheme.shapes.extraLarge
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    com.dking.crocapp.ui.components.StepTitle(
                        number = 2,
                        title = stringResource(R.string.receive_save_to)
                    )
                    // ── Save location row ──
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.large)
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            Icons.Rounded.FolderOpen,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            if (uiState.sessionOverrideUri != null) {
                                Text(
                                    text = stringResource(R.string.receive_save_to_session),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = uiState.receiveLocationLabel,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (uiState.sessionOverrideUri != null) {
                            IconButton(
                                onClick = { viewModel.clearSessionOverrideLocation() },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    Icons.Rounded.RestartAlt,
                                    contentDescription = stringResource(R.string.receive_reset_location),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        OutlinedButton(
                            onClick = { folderPickerLauncher.launch(null) },
                            enabled = !isTransferActive,
                            shape = MaterialTheme.shapes.medium,
                            modifier = Modifier.height(32.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                        ) {
                            Text(
                                text = stringResource(R.string.receive_change_location),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }

                }
            }

            // Friendly hint while nothing is happening yet
            if (uiState.transferState is CrocTransferState.Idle && uiState.receivedFiles.isEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.receive_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // ──── Transfer Progress — between code and received files ────
            AnimatedVisibility(
                visible = showTransferSection,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TransferProgressCard(
                        state = uiState.transferState,
                        isSending = false,
                        onCancel = { viewModel.cancelTransfer() },
                        onRetryLegacy = { viewModel.retryWithLegacy() },
                        onSwitchToLegacy = { viewModel.switchToLegacyForNextReceive() },
                        activeEngine = uiState.activeEngine
                    )
                    if (isTransferFinished) {
                        OutlinedButton(
                            onClick = { viewModel.dismissTransferResult() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = MaterialTheme.shapes.large
                        ) {
                            Text(stringResource(R.string.action_dismiss))
                        }
                    }
                }
            }

            // ──── Received Files ────
            if (uiState.receivedFiles.isNotEmpty()) {
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceContainerLow
                    ),
                    shape = MaterialTheme.shapes.extraLarge
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.receive_received_files),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "${uiState.receivedFiles.size} file${if (uiState.receivedFiles.size > 1) "s" else ""}",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        val filesToShow = if (showAllFiles) uiState.receivedFiles
                        else uiState.receivedFiles.take(MAX_VISIBLE_FILES)

                        filesToShow.forEach { file ->
                            ReceivedFileRow(
                                file = file,
                                onOpen = { openReceivedFile(context, file) },
                                onShare = { shareReceivedFile(context, file) }
                            )
                        }

                        if (uiState.receivedFiles.size > MAX_VISIBLE_FILES) {
                            val remaining = uiState.receivedFiles.size - MAX_VISIBLE_FILES
                            AssistChip(
                                onClick = { showAllFiles = !showAllFiles },
                                label = {
                                    Text(
                                        if (showAllFiles) "Show less"
                                        else "+$remaining more file${if (remaining > 1) "s" else ""}"
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // ──── Received Text ────
            val completedState = uiState.transferState as? CrocTransferState.Completed
            if (completedState?.receivedText != null) {
                val receivedText = completedState.receivedText ?: ""
                val isUrl = receivedText.trim().let {
                    it.startsWith("https://", ignoreCase = true) || it.startsWith("http://", ignoreCase = true)
                }

                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    ),
                    shape = MaterialTheme.shapes.extraLarge
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = stringResource(R.string.receive_received_text),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = formatBytes(completedState.totalBytes),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (isUrl) {
                                    IconButton(
                                        onClick = {
                                            try {
                                                val intent = android.content.Intent(
                                                    android.content.Intent.ACTION_VIEW,
                                                    android.net.Uri.parse(receivedText.trim())
                                                )
                                                context.startActivity(intent)
                                            } catch (_: Exception) {}
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Rounded.FolderOpen,
                                            contentDescription = "Open URL",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(
                                            androidx.compose.ui.text.AnnotatedString(receivedText)
                                        )
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Rounded.ContentPaste,
                                        contentDescription = "Copy text",
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = receivedText,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 12,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
internal fun ReceivedFileRow(
    file: ReceivedFile,
    onOpen: () -> Unit,
    onShare: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.AutoMirrored.Rounded.InsertDriveFile,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onTertiaryContainer
            )
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = file.name,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = file.savedLocation,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onOpen, modifier = Modifier.size(32.dp)) {
            Icon(
                Icons.Rounded.FolderOpen,
                contentDescription = "Open",
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
            Icon(
                Icons.Rounded.Share,
                contentDescription = "Share",
                modifier = Modifier.size(18.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SavedCodeChipWithActions(
    code: String,
    enabled: Boolean,
    onUse: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Box {
        AssistChip(
            onClick = onUse,
            enabled = enabled,
            label = {
                Text(
                    code,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            modifier = Modifier.combinedClickable(
                enabled = enabled,
                onClick = onUse,
                onLongClick = { showMenu = true }
            )
        )

        androidx.compose.material3.DropdownMenu(
            expanded = showMenu,
            onDismissRequest = { showMenu = false }
        ) {
            androidx.compose.material3.DropdownMenuItem(
                text = { Text(stringResource(R.string.receive_on_code)) },
                onClick = {
                    showMenu = false
                    onUse()
                },
                leadingIcon = {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            )
            androidx.compose.material3.DropdownMenuItem(
                text = { Text(stringResource(R.string.action_copy)) },
                onClick = {
                    showMenu = false
                    onCopy()
                },
                leadingIcon = {
                    Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            )
            androidx.compose.material3.DropdownMenuItem(
                text = { Text(stringResource(R.string.action_share)) },
                onClick = {
                    showMenu = false
                    onShare()
                },
                leadingIcon = {
                    Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            )
        }
    }
}
